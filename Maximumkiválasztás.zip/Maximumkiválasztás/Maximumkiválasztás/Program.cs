﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tomb=new int[10];
            Random veletlen = new Random();

            for (int i = 0; i < tomb.Length; i++)
            {
                tomb[i] = veletlen.Next(1,1001); 
            }
            
            Console.WriteLine("-------------------------");            
            Console.WriteLine("-----A tömb elemei: -----");
            Console.WriteLine("-------------------------");
            
            for (int i = 0; i < tomb.Length; i++)
            {
                Console.WriteLine(tomb[i]);
            }

            int maximum = tomb[0];                

            for (int j = 0; j < tomb.Length; j++)
			{
                if(tomb[j]>maximum)
                {
                    maximum = tomb[j];
                    j++;
                }
			}
            Console.WriteLine("-------------------------------");
            Console.WriteLine("A tömb legnagyobb eleme: {0}",maximum); 
            Console.WriteLine("-------------------------------");
            

            Console.ReadKey();

        }
    }
}
